#include <sample_usbd.h>

#include <stdio.h>
#include <string.h>
#include <zephyr/device.h>
#include <zephyr/drivers/uart.h>
#include <zephyr/kernel.h>
#include <zephyr/usb/usb_device.h>
#include <zephyr/usb/usbd.h>
#include <zephyr/logging/log.h>

LOG_MODULE_REGISTER(cdc_acm_sim, LOG_LEVEL_INF);

const struct device *const uart_dev = DEVICE_DT_GET_ONE(zephyr_cdc_acm_uart);

/* ==============================
   CONFIGURACIÓN PROTOCOLO
   ============================== */

#define SOF 0x7E
#define EOF 0x7F
#define ESCAPE_BYTE 0x7D
#define ESC_MASK 0x20

#define PAYLOAD_SIZE 64
#define ENCODED_MAX_SIZE (PAYLOAD_SIZE * 2 + 2)

#define SEND_PERIOD_MS 1
#define NUM_SENSORS 12

/* ==============================
   ENCODER
   ============================== */

size_t uart_frame_encode(uint8_t *dst, size_t dst_size,
                         const uint8_t *src, size_t src_len)
{
    size_t out_len = 0;

    if (dst_size < 2)
        return 0;

    dst[out_len++] = SOF;

    for (size_t i = 0; i < src_len; i++) {
        uint8_t byte = src[i];

        if (byte == SOF || byte == EOF || byte == ESCAPE_BYTE) {

            if (out_len + 2 > dst_size)
                return 0;

            dst[out_len++] = ESCAPE_BYTE;
            dst[out_len++] = byte ^ ESC_MASK;

        } else {

            if (out_len + 1 > dst_size)
                return 0;

            dst[out_len++] = byte;
        }
    }

    if (out_len + 1 > dst_size)
        return 0;

    dst[out_len++] = EOF;

    return out_len;
}

/* ==============================
   SIMULADOR
   ============================== */

static uint32_t global_seq = 0;
static uint8_t sensor_id = 0;

void sim_timer_handler(struct k_timer *timer_id)
{
    uint8_t payload[PAYLOAD_SIZE];
    uint8_t encoded[ENCODED_MAX_SIZE];

    /* =============================
       FORMATO PAYLOAD (64 bytes)
       =============================
       [0]      = ID sensor
       [1-3]    = secuencia (24 bits)
       [4-63]   = 60 bytes datos simulados
    */

    payload[0] = sensor_id;

    payload[1] = (global_seq >> 16) & 0xFF;
    payload[2] = (global_seq >> 8) & 0xFF;
    payload[3] = (global_seq) & 0xFF;

    for (int i = 4; i < PAYLOAD_SIZE; i++) {
        payload[i] = (uint8_t)(sensor_id + i + global_seq);
    }

    global_seq++;

    sensor_id++;
    if (sensor_id >= NUM_SENSORS)
        sensor_id = 0;

    /* =============================
       ENCAPSULAR
       ============================= */

    size_t enc_len = uart_frame_encode(encoded,
                                       sizeof(encoded),
                                       payload,
                                       PAYLOAD_SIZE);

    if (enc_len == 0)
        return;

    /* =============================
       ENVIAR POR CDC ACM
       ============================= */

    for (size_t i = 0; i < enc_len; i++) {
        uart_poll_out(uart_dev, encoded[i]);
    }
}

K_TIMER_DEFINE(sim_timer, sim_timer_handler, NULL);


/* ==============================
   MAIN
   ============================== */

#if defined(CONFIG_USB_DEVICE_STACK_NEXT)
static struct usbd_context *sample_usbd;
K_SEM_DEFINE(dtr_sem, 0, 1);

static void sample_msg_cb(struct usbd_context *const ctx,
                          const struct usbd_msg *msg)
{
    if (msg->type == USBD_MSG_CDC_ACM_CONTROL_LINE_STATE) {
        uint32_t dtr = 0U;
        uart_line_ctrl_get(msg->dev, UART_LINE_CTRL_DTR, &dtr);
        if (dtr)
            k_sem_give(&dtr_sem);
    }
}

static int enable_usb_device_next(void)
{
    sample_usbd = sample_usbd_init_device(sample_msg_cb);
    if (!sample_usbd)
        return -ENODEV;

    return usbd_enable(sample_usbd);
}
#endif

int main(void)
{
    int ret;

    if (!device_is_ready(uart_dev)) {
        LOG_ERR("CDC ACM device not ready");
        return 0;
    }

#if defined(CONFIG_USB_DEVICE_STACK_NEXT)
    ret = enable_usb_device_next();
#else
    ret = usb_enable(NULL);
#endif

    if (ret != 0) {
        LOG_ERR("Failed to enable USB");
        return 0;
    }

    LOG_INF("Wait for DTR");

#if defined(CONFIG_USB_DEVICE_STACK_NEXT)
    k_sem_take(&dtr_sem, K_FOREVER);
#else
    while (true) {
        uint32_t dtr = 0U;
        uart_line_ctrl_get(uart_dev, UART_LINE_CTRL_DTR, &dtr);
        if (dtr)
            break;
        k_sleep(K_MSEC(100));
    }
#endif

    LOG_INF("DTR set - starting simulation");

    k_msleep(100);

    k_timer_start(&sim_timer,
                  K_MSEC(SEND_PERIOD_MS),
                  K_MSEC(SEND_PERIOD_MS));

    return 0;
}
