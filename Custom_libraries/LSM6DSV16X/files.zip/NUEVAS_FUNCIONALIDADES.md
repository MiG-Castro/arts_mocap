# Nuevas Funcionalidades - LSM6DSV16X Driver

## 📦 **Funciones Añadidas**

### 1. **FIFO Batch Configuration**
### 2. **Axis Remapping (Software)**

---

## 1️⃣ **FIFO Batch Configuration**

### **Función**

```c
int lsm6dsv16x_fifo_batch_config(const lsm6dsv16x_config_t *config,
                                  bool accel_batch,
                                  bool gyro_batch,
                                  bool sflp_batch);
```

### **Descripción**

Controla qué sensores envían datos al FIFO. Permite configuraciones como:
- Solo SFLP en FIFO (máxima eficiencia)
- Solo Accel/Gyro en FIFO
- Combinaciones personalizadas

### **Parámetros**

- `config`: Configuración del sensor
- `accel_batch`: `true` = Accel va al FIFO, `false` = NO va al FIFO
- `gyro_batch`: `true` = Gyro va al FIFO, `false` = NO va al FIFO
- `sflp_batch`: `true` = SFLP va al FIFO, `false` = NO va al FIFO

### **Ejemplos de Uso**

#### **Ejemplo 1: Solo SFLP en FIFO (Recomendado)**

```c
/* Sensores rápidos para mejor fusión */
lsm6dsv16x_accel_config(&config, LSM6DSV16X_ACCEL_ODR_480_HZ,
                                  LSM6DSV16X_ACCEL_FS_4G);
lsm6dsv16x_gyro_config(&config, LSM6DSV16X_GYRO_ODR_480_HZ,
                                 LSM6DSV16X_GYRO_FS_2000_DPS);

/* SFLP a frecuencia de aplicación */
lsm6dsv16x_sflp_enable(&config, LSM6DSV16X_SFLP_ODR_120_HZ);

/* Solo quaternions en FIFO */
lsm6dsv16x_fifo_batch_config(&config, 
                             false,  // Accel NO va al FIFO
                             false,  // Gyro NO va al FIFO
                             true);  // SFLP SÍ va al FIFO

/* Resultado:
 * - Accel trabaja @ 480 Hz internamente
 * - Gyro trabaja @ 480 Hz internamente
 * - SFLP decima 4:1 → 120 Hz
 * - FIFO recibe solo quaternions @ 120 Hz
 * - Capacidad: ~5.5 segundos de datos
 */

/* Si necesitas datos raw, léelos directamente */
lsm6dsv16x_accel_read_raw(&config, &accel_raw);
lsm6dsv16x_gyro_read_raw(&config, &gyro_raw);
```

#### **Ejemplo 2: Todo en FIFO**

```c
/* Todo a la misma frecuencia */
lsm6dsv16x_accel_config(&config, LSM6DSV16X_ACCEL_ODR_120_HZ, ...);
lsm6dsv16x_gyro_config(&config, LSM6DSV16X_GYRO_ODR_120_HZ, ...);
lsm6dsv16x_sflp_enable(&config, LSM6DSV16X_SFLP_ODR_120_HZ);

/* Todo al FIFO */
lsm6dsv16x_fifo_batch_config(&config, true, true, true);

/* FIFO contendrá:
 * - Tag 0x02: Accel @ 120 Hz
 * - Tag 0x01: Gyro @ 120 Hz  
 * - Tag 0x13: Quaternion @ 120 Hz
 * - Capacidad: ~1.8 segundos de datos
 */
```

#### **Ejemplo 3: Solo datos raw, sin SFLP**

```c
lsm6dsv16x_accel_config(&config, LSM6DSV16X_ACCEL_ODR_480_HZ, ...);
lsm6dsv16x_gyro_config(&config, LSM6DSV16X_GYRO_ODR_480_HZ, ...);

/* Accel y Gyro al FIFO, SFLP deshabilitado */
lsm6dsv16x_fifo_batch_config(&config, true, true, false);

/* FIFO contendrá solo datos raw a 480 Hz */
```

### **Ventajas**

✅ **Eficiencia de FIFO**: Más tiempo de buffer con solo datos necesarios  
✅ **Flexibilidad**: Combina alta velocidad interna con baja frecuencia de salida  
✅ **Ahorro de energía**: Lee FIFO menos frecuentemente  

---

## 2️⃣ **Axis Remapping (Software)**

### **⚠️ IMPORTANTE**

El LSM6DSV16X **NO tiene hardware axis remap** para el acelerómetro y giroscopio internos.

**El hardware remap solo existe para sensores externos** conectados al Sensor Hub.

Por eso, implementamos **software axis remap** en el driver.

### **Enumeración de Modos**

```c
typedef enum {
    LSM6DSV16X_REMAP_NONE = 0,      // Sin cambios
    LSM6DSV16X_REMAP_X_NEG,         // X → -X
    LSM6DSV16X_REMAP_Y_NEG,         // Y → -Y
    LSM6DSV16X_REMAP_Z_NEG,         // Z → -Z
    LSM6DSV16X_REMAP_XY_SWAP,       // X ↔ Y
    LSM6DSV16X_REMAP_XZ_SWAP,       // X ↔ Z
    LSM6DSV16X_REMAP_YZ_SWAP,       // Y ↔ Z
    LSM6DSV16X_REMAP_BOARD_90,      // Rotación 90°
    LSM6DSV16X_REMAP_BOARD_180,     // Rotación 180°
    LSM6DSV16X_REMAP_BOARD_270,     // Rotación 270°
} lsm6dsv16x_axis_remap_t;
```

### **Funciones**

```c
void lsm6dsv16x_accel_remap(const lsm6dsv16x_accel_raw_t *input,
                             lsm6dsv16x_accel_raw_t *output,
                             lsm6dsv16x_axis_remap_t mode);

void lsm6dsv16x_gyro_remap(const lsm6dsv16x_gyro_raw_t *input,
                            lsm6dsv16x_gyro_raw_t *output,
                            lsm6dsv16x_axis_remap_t mode);
```

### **Ejemplos de Uso**

#### **Ejemplo 1: Sensor montado 90° rotado**

```c
lsm6dsv16x_accel_raw_t accel_raw, accel_remapped;
lsm6dsv16x_gyro_raw_t gyro_raw, gyro_remapped;

/* Leer datos */
lsm6dsv16x_accel_read_raw(&config, &accel_raw);
lsm6dsv16x_gyro_read_raw(&config, &gyro_raw);

/* Aplicar rotación de 90° */
lsm6dsv16x_accel_remap(&accel_raw, &accel_remapped, 
                       LSM6DSV16X_REMAP_BOARD_90);
lsm6dsv16x_gyro_remap(&gyro_raw, &gyro_remapped,
                      LSM6DSV16X_REMAP_BOARD_90);

/* Ahora accel_remapped y gyro_remapped están en la orientación correcta */
```

#### **Ejemplo 2: Invertir eje Z**

```c
/* Sensor montado al revés (Z hacia abajo) */
lsm6dsv16x_accel_remap(&accel_raw, &accel_remapped,
                       LSM6DSV16X_REMAP_Z_NEG);
lsm6dsv16x_gyro_remap(&gyro_raw, &gyro_remapped,
                      LSM6DSV16X_REMAP_Z_NEG);
```

#### **Ejemplo 3: Intercambiar X e Y**

```c
/* PCB rotada, X e Y intercambiados */
lsm6dsv16x_accel_remap(&accel_raw, &accel_remapped,
                       LSM6DSV16X_REMAP_XY_SWAP);
lsm6dsv16x_gyro_remap(&gyro_raw, &gyro_remapped,
                      LSM6DSV16X_REMAP_XY_SWAP);
```

### **Tabla de Transformaciones**

| Modo | X' | Y' | Z' | Descripción |
|------|----|----|----|-----------| 
| NONE | X | Y | Z | Sin cambios |
| X_NEG | -X | Y | Z | Invertir X |
| Y_NEG | X | -Y | Z | Invertir Y |
| Z_NEG | X | Y | -Z | Invertir Z |
| XY_SWAP | Y | X | Z | Intercambiar X↔Y |
| XZ_SWAP | Z | Y | X | Intercambiar X↔Z |
| YZ_SWAP | X | Z | Y | Intercambiar Y↔Z |
| BOARD_90 | Y | -X | Z | Rotar 90° en XY |
| BOARD_180 | -X | -Y | Z | Rotar 180° en XY |
| BOARD_270 | -Y | X | Z | Rotar 270° en XY |

### **Diagrama Visual de Rotaciones**

```
Vista desde arriba (mirando hacia -Z):

Original:          BOARD_90:         BOARD_180:        BOARD_270:
    Y                  Y                  Y                 Y
    ↑                  ↑                  ↑                 ↑
    |                  |                  |                 |
    +--→ X         -X←-+              -Y←-+             X--→+
                       |                  |                 |
                       ↓                  ↓                 ↓
                       X                 -X                -Y

Rotación:        90° CCW            180°              270° CCW
Transformación:  X→Y, Y→-X         X→-X, Y→-Y        X→-Y, Y→X
```

### **¿Cuándo Usar Axis Remap?**

✅ **Úsalo cuando:**
- El sensor está montado en orientación diferente al diseño del PCB
- Necesitas corregir la orientación sin modificar el código de aplicación
- Quieres usar un sistema de coordenadas estándar

❌ **No lo necesitas si:**
- El sensor está montado correctamente
- Tu aplicación puede manejar cualquier orientación
- Usas solo magnitudes (sin dirección)

### **Rendimiento**

- **Overhead**: Mínimo (solo operaciones aritméticas simples)
- **Memoria**: No requiere memoria adicional
- **Velocidad**: < 1 µs por transformación

---

## 📊 **Configuración Óptima: FIFO + Axis Remap**

```c
/* 1. Inicializar sensor */
lsm6dsv16x_init(&config);

/* 2. Configurar sensores a alta velocidad */
lsm6dsv16x_accel_config(&config, LSM6DSV16X_ACCEL_ODR_480_HZ,
                                  LSM6DSV16X_ACCEL_FS_4G);
lsm6dsv16x_gyro_config(&config, LSM6DSV16X_GYRO_ODR_480_HZ,
                                 LSM6DSV16X_GYRO_FS_2000_DPS);

/* 3. Habilitar SFLP a frecuencia de aplicación */
lsm6dsv16x_sflp_enable(&config, LSM6DSV16X_SFLP_ODR_120_HZ);

/* 4. Solo SFLP en FIFO */
lsm6dsv16x_fifo_batch_config(&config, false, false, true);

/* 5. Loop de lectura */
while (1) {
    uint16_t fifo_count;
    lsm6dsv16x_fifo_sample_t sample;
    lsm6dsv16x_quaternion_t quat;
    
    /* Leer FIFO (quaternions) */
    lsm6dsv16x_fifo_get_count(&config, &fifo_count);
    
    for (int i = 0; i < fifo_count; i++) {
        lsm6dsv16x_fifo_read_sample(&config, &sample);
        
        if (sample.tag == LSM6DSV16X_FIFO_TAG_SFLP_QUAT) {
            lsm6dsv16x_sflp_to_quaternion(sample.data, &quat);
            // Procesar quaternion...
        }
    }
    
    /* Si necesitas raw data (rara vez) */
    if (need_raw_data) {
        lsm6dsv16x_accel_raw_t accel_raw, accel_remapped;
        lsm6dsv16x_gyro_raw_t gyro_raw, gyro_remapped;
        
        /* Leer directamente desde registros */
        lsm6dsv16x_accel_read_raw(&config, &accel_raw);
        lsm6dsv16x_gyro_read_raw(&config, &gyro_raw);
        
        /* Aplicar remap si el sensor está rotado */
        lsm6dsv16x_accel_remap(&accel_raw, &accel_remapped,
                               LSM6DSV16X_REMAP_BOARD_90);
        lsm6dsv16x_gyro_remap(&gyro_raw, &gyro_remapped,
                              LSM6DSV16X_REMAP_BOARD_90);
        
        // Procesar datos raw remapeados...
    }
    
    k_msleep(100);  // Leer cada 100ms
}
```

---

## 🎯 **Resumen**

### **FIFO Batch Configuration**
- ✅ Control granular de qué va al FIFO
- ✅ Máxima eficiencia: sensores rápidos + FIFO lento
- ✅ Función: `lsm6dsv16x_fifo_batch_config()`

### **Axis Remapping**
- ⚠️ Solo por software (no hay hardware remap para accel/gyro internos)
- ✅ 10 modos pre-definidos comunes
- ✅ Cero overhead de memoria
- ✅ Funciones: `lsm6dsv16x_accel_remap()`, `lsm6dsv16x_gyro_remap()`

### **Configuración Recomendada**
```
Accel/Gyro: 480 Hz internamente
SFLP: 120 Hz salida
FIFO: Solo quaternions
Raw data: Lectura directa cuando se necesite + remap
```

**Resultado:** Sistema eficiente, flexible y fácil de usar 🚀

---

## 📝 **Notas sobre Hardware Remap (Sensores Externos)**

El LSM6DSV16X **SÍ tiene** funciones de axis remap en hardware, pero **SOLO funcionan para sensores externos** conectados al Sensor Hub:

```c
/* ESTAS FUNCIONES SOLO FUNCIONAN PARA SENSORES EXTERNOS */

// Configurar orientación de ejes de sensor externo
lsm6dsv16x_fsm_ext_sens_x_orient_set();  // Solo para ext sensor
lsm6dsv16x_fsm_ext_sens_y_orient_set();  // Solo para ext sensor
lsm6dsv16x_fsm_ext_sens_z_orient_set();  // Solo para ext sensor

// Matriz de transformación para sensor externo
lsm6dsv16x_fsm_ext_sens_matrix_set();    // Solo para ext sensor
```

**NO intentes usar estas funciones** para el acelerómetro o giroscopio internos - no funcionarán. Usa las funciones de software remap que hemos implementado.

---

¡Listo! Ahora tienes control completo sobre:
1. Qué datos van al FIFO
2. Cómo corregir la orientación del sensor

🎉
